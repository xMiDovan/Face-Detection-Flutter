<?php

$db_name = "u642446173_db_data";
$mysql_username = "u642446173_db_data";
$mysql_password = "261422@@mN";
$server_name = "127.0.0.1";
$conn = mysqli_connect($server_name, $mysql_username, $mysql_password, $db_name);

// Check if the connection to the database is successful
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// SQL query to fetch the last 10 image URLs
$sql = "SELECT * FROM tbl_face_images ORDER BY id DESC LIMIT 10"; // Order by id in descending order to get the latest images

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row
    $output = array();
    while($row = $result->fetch_assoc()) {
        $output[] = $row;
    }
    echo json_encode($output); // Output image URLs as JSON
} else {
    echo "0 results";
}
$conn->close();
?>
