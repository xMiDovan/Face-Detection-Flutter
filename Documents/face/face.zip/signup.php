<?php
header('Content-Type: application/json');

$db_name = "u642446173_db_data";
$mysql_username = "u642446173_db_data";
$mysql_password = "261422@@mN";
$server_name = "127.0.0.1";
$conn = mysqli_connect($server_name, $mysql_username, $mysql_password, $db_name);

// Check if the connection to the database is successful
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Endpoint for user registration
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle registration logic and save user data to the database
    $data = json_decode(file_get_contents('php://input'), true);

    // Extract values from $data
    $username = $data['username'];
    $email = $data['email'];
    $password = $data['password'];

    // Check if email is already taken
    $checkEmailQuery = "SELECT * FROM tbl_face_account WHERE email = '$email'";
    $emailResult = $conn->query($checkEmailQuery);

    if ($emailResult->num_rows > 0) {
        // Email is already taken, return an error response
        echo json_encode(['message' => 'Email is already taken']);
    } else {
        // Email is not taken, proceed with user registration
        $sql = "INSERT INTO tbl_face_account (username, email, password) VALUES ('$username', '$email', '$password')";
    
        if ($conn->query($sql) === TRUE) {
            echo json_encode(['message' => 'User registered successfully']);
        } else {
            echo json_encode(['message' => 'Error: ' . $conn->error]);
        }
    }
}
// Endpoint for user login
else if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle login logic, validate credentials, and generate a token
    $data = json_decode(file_get_contents('php://input'), true);

    // Extract values from $data
    $username = $data['username'];
    $password = $data['password'];

    // Perform login validation (customize this part based on your actual login logic)
    // ...

    // Assuming validation is successful, generate a token
    $token = 'your_generated_token';

    echo json_encode(['token' => $token]);
}

else {
    echo json_encode(['error' => 'Invalid request']);
}

// Close the database connection
mysqli_close($conn);
?>