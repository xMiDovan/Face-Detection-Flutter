<?php

echo"XXX";
$db_name = "u642446173_db_data";
$mysql_username = "u642446173_db_data";
$mysql_password = "261422@@mN";
$server_name = "127.0.0.1";
$conn = mysqli_connect($server_name, $mysql_username, $mysql_password, $db_name);

if($conn){
	
    // http://mthesis.com/fish/save_wt.php?a=100.3&b=102.2&c=103.3&avet=101.1&avef=50.5
    // https://mthesis.com/fish/save_wt.php?a=90.3&b=92.2&c=93.3&avet=91.1&avef=45.5
    // echo "Connected";
    if( $_GET["name"]) {
	   
	       $name = $_GET['name']; 
	       
	       date_default_timezone_set('Singapore');
           $dates =  date("F j, Y");
           $times =  date("H:i");

           $sql = "INSERT INTO tbl_face_transact(id,name,dates,times)
            VALUES (NULL, '$name','$dates' ,'$times')";
           
    
            if ($conn->query($sql) === TRUE) {
                echo "New record created successfully". "<br>";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }

    }
}
else{
    echo "Connection Not Success";	
        die("Connection failed: " . mysqli_connect_error());
}


?>