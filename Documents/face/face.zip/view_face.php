<?php

$spaces = str_repeat(" ", 5);

$db_name = "u642446173_db_data";
$mysql_username = "u642446173_db_data";
$mysql_password = "261422@@mN";
$server_name = "127.0.0.1";
$conn = mysqli_connect($server_name, $mysql_username, $mysql_password, $db_name);

if($conn){
    $sql = "SELECT * FROM tbl_face_transact ORDER BY id DESC LIMIT 20";
    // $sql = "SELECT id, firstname, lastname FROM MyGuests WHERE lastname='Doe'";
    $result = mysqli_query($conn, $sql);
    $cnt = mysqli_num_rows($result);
    while($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
      
        // echo $row['name'] . $spaces;
        // echo $row['dates'] . $spaces; 
        // echo $row['times'] . "_"; 
    }
    header('Content-Type: application/json');
    echo json_encode($data);
   $conn->close();
}
else{
	echo "Connection Not Success";	
        die("Connection failed: " . mysqli_connect_error());
}

?>