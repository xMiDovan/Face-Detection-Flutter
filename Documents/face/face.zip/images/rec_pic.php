<?php
print_r($_FILES);
move_uploaded_file($_FILES["file"]["tmp_name"],$_FILES["file"]["name"]);

// https://mthesis.com/face/images/17.jpg


$db_name = "u642446173_db_data";
$mysql_username = "u642446173_db_data";
$mysql_password = "261422@@mN";
$server_name = "127.0.0.1";
$conn = mysqli_connect($server_name, $mysql_username, $mysql_password, $db_name);

if($conn){
    $sql = "SELECT * FROM tbl_face_images";
    // $sql = "SELECT id, firstname, lastname FROM MyGuests WHERE lastname='Doe'";
    $result = mysqli_query($conn, $sql);
    $cnt = mysqli_num_rows($result);
    while($row = mysqli_fetch_assoc($result)) {
        
    } 
   $conn->close();
}
else{
	echo "Connection Not Success";	
        die("Connection failed: " . mysqli_connect_error());
}

$cnt = $cnt + 1;
$url = "https://mthesis.com/face/images/" . $cnt . ".jpg";

$db_name = "u642446173_db_data";
$mysql_username = "u642446173_db_data";
$mysql_password = "261422@@mN";
$server_name = "127.0.0.1";
$conn = mysqli_connect($server_name, $mysql_username, $mysql_password, $db_name);

if($conn){


   $sql = "INSERT INTO tbl_face_images(id,url,name)
    VALUES (NULL, '$url',' ')";
   

    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully". "<br>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

}
else{
    echo "Connection Not Success";	
        die("Connection failed: " . mysqli_connect_error());
}

?>