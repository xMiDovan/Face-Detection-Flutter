<?php
header('Content-Type: application/json');

$db_name = "u642446173_db_data";
$mysql_username = "u642446173_db_data";
$mysql_password = "261422@@mN";
$server_name = "127.0.0.1";
$conn = mysqli_connect($server_name, $mysql_username, $mysql_password, $db_name);

// Check if the connection to the database is successful
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Endpoint for user login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle login logic and validate credentials
    $data = json_decode(file_get_contents('php://input'), true);

    // Extract values from $data
    $email = $data['email'];
    $password = $data['password'];

     // Query the database to check if the user exists and the password matches
    $query = "SELECT * FROM tbl_face_account WHERE username='$email' AND password='$password'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {
        if($email == 'admin')
        {
            echo json_encode(['message' => 'Admin Login']);
        }
        else{
            $token = 'your_generated_token';
            echo json_encode(['message' => 'User login successfully']);
        }
    } else {
        // Authentication failed
        echo json_encode(['message' => 'Invalid username or password']);
    }

    
} else {
    echo json_encode(['error' => 'Invalid request']);
}

// Close the database connection
mysqli_close($conn);
?>